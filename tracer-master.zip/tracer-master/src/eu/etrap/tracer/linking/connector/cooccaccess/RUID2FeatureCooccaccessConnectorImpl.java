/*
 * The Tracer project is a result of Marco Büchler's PhD in computer science about
 * 'Computational Aspects of the Historical Text Re-use and Knowledge Transfer'.
 * Tracer includes a six level architecture consisting of
 *      - Preprocessing (eu.etrap.tracer.preprocessing)
 *      - Training (eu.etrap.tracer.featuring)
 *      - Selection (eu.etrap.tracer.selection)
 *      - Linking (eu.etrap.tracer.linking)
 *      - Scoring (eu.etrap.tracer.scoring)
 *      - Postprocessing (eu.etrap.tracer.postprocessing).
 *
 * Tracer is provided both by open source and open access for non-commercial use.
 *
 * If you have any questions, please, send me an e-mail to mbuechler@etrap.eu.
 *
 * Marco Büchler
 * eTRAP Research Group 
 * Institute for Computer Science
 * Georg-August-Universiy Göttingen
 * Papendiek 16
 * 37073 Göttingen, Germany
 * web: http://www.etrap.eu
 *
 * This project has begun at the Leipzig e-Humanities Research Group at Leipzig
 * University, Germany is now continued as part of the eTRAP research group 
 * (http://www.etrap.eu).
 *
 */



package eu.etrap.tracer.linking.connector.cooccaccess;

import eu.etrap.medusa.config.ConfigurationContainer;
import eu.etrap.medusa.config.ConfigurationException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import eu.etrap.tracer.linking.LinkingException;
import eu.etrap.tracer.linking.connector.Connector;

/**
 * Created on 07.05.2011 11:35:37 by mbuechler
 * @author Marco Büchler: mbuechler@etrap.eu
 */
public class RUID2FeatureCooccaccessConnectorImpl extends AbstractCooccaccessConnector implements Connector {

    @Override
    public void init() throws ConfigurationException {
        super.init();

        strTaxonomyCode = "01-02-02-01";
    }

    @Override
    public void prepareData(String strSource) throws LinkingException {
        try {
            // inverted file
            String strRUID2FeatureFileName = strSource + ".r2f";

            if (!new File(strRUID2FeatureFileName).exists()) {
                ConfigurationContainer.println("\tPreparing cooccaccess data for ruid2feat in file " + strRUID2FeatureFileName);
                BufferedReader objReader = new BufferedReader(new FileReader(strSource));
                BufferedWriter objWriter = new BufferedWriter(new FileWriter(strRUID2FeatureFileName));

                String strLine = null;
                while ((strLine = objReader.readLine()) != null) {
                    String strSplit[] = strLine.split("\t");
                    objWriter.write(strSplit[1] + "\t" + strSplit[0] + "\n");
                }

                objReader.close();
                objWriter.flush();
                objWriter.close();
            } else {
                ConfigurationContainer.println("\tcooccaccess data for ruid2feat are ALREADY prepared in file " + strRUID2FeatureFileName);
            }

            super.prepareData(strRUID2FeatureFileName);
        } catch (Exception e) {
            throw new LinkingException(e);
        }
    }
}
