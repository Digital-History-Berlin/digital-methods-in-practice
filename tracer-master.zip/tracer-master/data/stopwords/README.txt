::::::::::::::::::::::::::::::::::::
Stopwords source list
::::::::::::::::::::::::::::::::::::


- Latin: https://raw.githubusercontent.com/aurelberra/stopwords/v1.0.0/stopwords_latin.txt