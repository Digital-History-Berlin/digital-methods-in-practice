This repository contains the TRACER framework for automatic detection of historical text reuse.

A growing bibliography of historical text reuse is available here: https://www.zotero.org/groups/500373/historical_text_reuse?
